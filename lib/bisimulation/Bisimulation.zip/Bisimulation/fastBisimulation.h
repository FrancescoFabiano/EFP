//------------------------------------------------------------------------------
//Title:       Fast Bisimulation
//Version:     9.1
//Author:      Ugel Nadia
//Company:     University of Udine
//Description: this header file contains the data structures definition and
//             declaration and also function prototypes
//------------------------------------------------------------------------------

//CONSTANT DECLARATION
//max lenght of the array
const int MAXINDEX = 100000;
//DFS constants
const int WHITE=0, GRAY=1, BLACK=2;

//STRUCTURE DECLARATION
//index is the type of the implicit pointers to the array
//hence is a number that belongs to the range [-1..numberOfNodes]
//at the moment we simply use integer;
//later it could become log(numberOfNodes) bits
typedef int indexType;
const indexType NIL=-1;

//adjacency list
struct adjList{
  indexType node;
  struct counter *countxS; //pointer to the count(x,S) of Paige&Tarjan
  struct adjList *next;
};

//adjacency list of G_1
struct adjList_1{
  indexType node;
  struct adjList *adj; //pointer to the corrispondente edge in G
  struct adjList_1 *next;
};

//counters for Paige and Tarjan
struct counter{
  indexType value;
  indexType node;
};

//graph: array of nodes
struct graph {
  int label; //label of the node
  indexType rank; //rank of the node
  bool WFflag; //identifies if the node is WF(0 NWF,1 WF)
  indexType nextInBlock; //pointer to the next node in the same block
  indexType prevInBlock; //pointer to the previous node in the same block
  indexType block;  //pointer to the block
  struct counter *countxB;  //pointer to count(x,B)
  struct adjList *adj; //pointer to the adjacency list
  struct adjList_1 *adj_1; //pointer to the adjacency list of G-1
};

//information related to Q-Blocks
struct qPartition{
  indexType size; //number of nodes in the block
              //normalisation of the rank values: normalisation array
  indexType nextBlock; //pointer to the next Q-Block
              //normalisation of the rank values: copy of the forefather's rank
  indexType prevBlock; //pointer to the prvious Q-Block
              //during DFS-visit: color of the nodes
  indexType superBlock; //pointer to the X-Block containing the current Q-Block
              //during DFS: forefather
  indexType firstNode; //pointer to the first node in the block
              //during the first DFS visit in SCC(): finishing time
};

//information related to X-Blocks
struct xPartition{
  indexType nextXBlock; //pointer to the next X-Block
  indexType prevXBlock; //pointer to the previous X-Block
  indexType firstBlock; //pointer to the first Block in X
};


//SHARED DATA STRUCTURES
//the graph
  extern struct graph G[];
  extern struct qPartition Q[];
  extern struct xPartition X[];
  extern int numberOfNodes;
//pointer to the complete structure of the graph (G,Q,X)
  extern indexType C;

//pointers to maintain the free space in Q and X
  extern indexType freeQBlock,QBlockLimit;
  extern indexType freeXBlock;

  extern adjList_1 *borderEdges[];


//FUNCTIONS' PROTOTYPES

//from  PaigeTarjan
  void PaigeTarjan();
  int InitPaigeTarjan();
//from  PaigeTarjanBonic
  bool MultipleNodes(indexType);
  void PaigeTarjanBonic();
//from FastBisimulation
  void Inverse();
  void Rank();
  void PaigeTarjan(indexType);
  void FastBisimulationAlgorithm();
  void DisposeGraph();
  int InitFBA();

/*REMEMBER: if the input/output interface is changed, it is necessary to change
only the initialisation functions:  InitPaigeTarjan() for PaigeTarjan and
InitFBA() for FastBisimulation*/


