//------------------------------------------------------------------------------
//Title:       FC2 format interface
//Version:     1.0
//Author:      Thomas Dolso, Alberto Forti
//Company:     Universit� degli Studi di Udine
//Description: 
//------------------------------------------------------------------------------


#include <stdlib.h>
//DATA STRUCTURES USED FOR THE INPUT AND THE OUTPUT FROM FC2 FILES
typedef struct e_elem_struct e_elem ;
typedef struct v_elem_struct v_elem ;
typedef struct bhtab_struct bhtab ;
typedef struct automa_struct automa;

struct e_elem_struct {
    int     nbh ;   // Number of lables (behaviors) of a single Edge
    int     *bh ;   // Array of Behaviors
    int     tv ;    // Index (of the array of vertices) of the "To" Vertex
};

struct v_elem_struct {
    int     ne ;    // Number of Edges
    e_elem  *e ;    // Vettore di edges
};

struct bhtab_struct {
    int     ap;     // Azioni Predefinite (set to 0)
    int     n ;     // Number of Behaviors (Agents)
    char    **bh ;  // Name of the Behaviors (Agents)
};

struct automa_struct {
  int    Nvertex;
  int    Nbehavs;
  v_elem *Vertex;
  bhtab  *behavs;
};

extern char *inputName, *outputName;

// PROTOTYPES
automa *LoadFromFC2(char *);
void GetMinimizedAutoma(automa *);
void MarkDeletedNodes();
void DeleteNodes(automa *A);

void SaveToFC2(automa *,char *);

void FillStructures(automa *A) ;
void CreateG(int num_v, v_elem *Gtemp) ;
void SetPointers(int n) ;

void VisAutoma(automa *);
void DisposeAutoma(automa *);
void error(char *);


 