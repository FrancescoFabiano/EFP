//------------------------------------------------------------------------------
//Title:       Fast Bisimulation
//Version:     9.1
//Author:      Dolso Thomas, Forti Alberto and Ugel Nadia
//Company:     University of Udine
//Description: this file contains the testing of Bisimulation
//             where the input graphs come from file of type FC2
//------------------------------------------------------------------------------
#include "fastBisimulation.h"
#include "IO_FC2.h"
#include <iostream>
#include <string.h> 

//prototypes
void Output();

char *inputName, *outputName;  

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

void ScriviHelp()
{
  printf("\n\nSpecificare i seguenti argomenti:\n") ;
  printf("\n  1. -pt (-PT) per PaigeTarjan, oppure -fba (-FBA) per FastBisimulation") ;
  printf("\n  2. il nome del file di input (formato FC2)") ;
  printf("\n  3. il nome del file di output\n") ;
  exit(0) ;
}


int main( int argc, char *argv[] )
{
  int ptfba;
  automa *aut;
  clock_t start, stop;


  // controllo sugli argomenti passati come input
  if ( argc != 4 ) ScriviHelp();
  else {
      if ( (strcmp(argv[1],"-pt") == 0) || (strcmp(argv[1],"-PT") == 0) )
          ptfba = 1 ;
      else if ( (strcmp(argv[1],"-fba") == 0) || (strcmp(argv[1],"-FBA") == 0) )
          ptfba = 0 ;
      else ScriviHelp();
      inputName = argv[2] ;
      outputName = argv[3] ;
  }

  aut = LoadFromFC2(inputName);

  start = clock();

  Inverse();

  if (ptfba==0){
    Rank();
    if (InitFBA()==0){
      FastBisimulationAlgorithm();
    }
  }else{
    if (InitPaigeTarjan()==0)
      PaigeTarjan();
  }

  stop = clock();

  SaveToFC2(aut,outputName);

  DisposeAutoma(aut) ;

  printf("\n\nNumero effettivo di nodi: %d\n",numberOfNodes);
  printf("\nTempo di esecuzione (escluso I/O da file): %lf secondi\n",
            ((double)(stop-start)) / CLOCKS_PER_SEC);

  return 0;
}

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

void Output()
{
  indexType i;

  std::cout <<"n\tr\tnIB\tpIB\tb\n s\t nB\t pB\t sB\t fN\n  nxB\t  pXB\t  fB\n\n";
  for (i=0;i<numberOfNodes;i++){
    std::cout <<i<<"\t"<<G[i].rank<<"\t"<<G[i].nextInBlock<<"\t"<<G[i].prevInBlock
        <<"\t"<<G[i].block
    <<"\n "<<Q[i].size<<"\t "<<Q[i].nextBlock<<"\t "<<Q[i].prevBlock<<"\t "
        <<Q[i].superBlock<<"\t "<<Q[i].firstNode
    <<"\n  "<<X[i].nextXBlock<<"\t  "<<X[i].prevXBlock<<"\t  "
        <<X[i].firstBlock<<std::endl;
  }
  std::cout <<"----------------------\n";
}