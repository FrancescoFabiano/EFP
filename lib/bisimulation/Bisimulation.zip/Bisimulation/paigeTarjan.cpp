//------------------------------------------------------------------------------
//Title:       Fast Bisimulation
//Version:     9.1
//Author:      Ugel Nadia
//Company:     University of Udine
//Description: this file contains the Paige and Tajan Algorithm
//------------------------------------------------------------------------------
#include "fastBisimulation.h"
#include <iostream>//debug

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

//local variables shared between PaigeTarjan() and PaigeTarjan(indexType)
extern indexType B1[MAXINDEX]; //copy of B
extern indexType B_1[MAXINDEX];  //list to maintain E-1(B) and E-1(S-B)
extern indexType splitD[MAXINDEX]; //list of split blocks
extern indexType b1List, b_1List, dList;//starting pointers of the lists above
  /*this kind of lists permits random access to the nodes that are in the list
  and we can control if there are duplicates in O(1);
  moreover we can scan them using the starting pointer and
  proceeding in the chain with the next pointers*/

//initialise paige and Tarjan
int InitPaigeTarjan()
{
  indexType i,l,end,temp;
  struct counter *cxS;
  struct adjList *adj;

  //initialisation of the graph (G,Q,X)
  for (l=0;l!=NIL;l=temp){ //for each label block
    temp = X[l].nextXBlock;
    if (temp==NIL)
      end = l;
    Q[l].prevBlock = X[l].prevXBlock;
    Q[l].nextBlock = X[l].nextXBlock;
    Q[l].firstNode = X[l].firstBlock;
    Q[l].superBlock = 0;
    //compute Q[].size
    Q[l].size = 0;
    for (i=X[l].firstBlock;i!=NIL;i=G[i].nextInBlock)//for each node
      (Q[l].size)++;
    X[l].prevXBlock = NIL;
    X[l].firstBlock = NIL;
    X[l].nextXBlock = l+1;

    B1[l] = numberOfNodes;
    B_1[l] = numberOfNodes;
    B_1[l] = numberOfNodes;
    splitD[l] = numberOfNodes;
  }

  X[0].nextXBlock = NIL;
  X[0].prevXBlock = NIL;
  X[0].firstBlock = 0;

  if (end==numberOfNodes)
    freeQBlock = NIL;
  else
    freeQBlock = end+1;
  QBlockLimit = numberOfNodes;
  freeXBlock = 1;

  for (i=end+1;i<numberOfNodes;i++){
    Q[i].size = 0;
    Q[i].nextBlock = i+1;
    Q[i].superBlock = NIL;
    Q[i].prevBlock = NIL;
    Q[i].firstNode = NIL;

    X[i].nextXBlock = i+1;
    X[i].prevXBlock = NIL;
    X[i].firstBlock = NIL;

    B1[i] = numberOfNodes;
    B_1[i] = numberOfNodes;
    B_1[i] = numberOfNodes;
    splitD[i] = numberOfNodes;
  }
  Q[numberOfNodes-1].nextBlock = NIL;
  X[numberOfNodes-1].nextXBlock = NIL;


  if (Q[0].nextBlock==NIL) //P&T not necessary
    return 1;

  C = 0;
  //initialisation of the counters
  //initially there is a count per node count(x,U)=|E({x})|
  for (i=0;i<numberOfNodes;i++){
    adj = G[i].adj;
    //to avoid the creation of a counter set to zero
    if (adj==NULL)
      continue;
    cxS = new struct counter;
    cxS->value = 0;
    while (adj!=NULL){
      (cxS->value)++;
      /*each edge xEy contains a pointer to count(x,U);
      remember that each edge y(E-1)x contains a pointer to the edge xEy!*/
      adj->countxS = cxS;
      adj = adj->next;
    }
  }
  return 0;
}

//compute Paige and Tarjan
void PaigeTarjan()
{
  indexType S, S1;  //pointer to the X-Blocks S and S1
  indexType B, S_B;  //pointer to the Q-Blocks B and S-B
  indexType oldD, newD; //old and new block of x belonging to E-1(B)
  struct adjList_1 *adj;
  struct counter *cxS;
  indexType x,y,d,e;

  while (C!= NIL){

  /*Step 1(select a refining block) & Step 2(update X)*/
    //select some block S from C
    S = C;
    /*if S has more than two blocks, it has to be put back to C;
    hence it is not removed from X until we are sure it is not still
    compound after removing B from it*/

    /*examine the first two blocks in the of blocks of Q contained in S;
    let B be the smaller, remove B from S*/
    if (Q[X[S].firstBlock].size < Q[Q[X[S].firstBlock].nextBlock].size){
      B = X[S].firstBlock;
      S_B = Q[X[S].firstBlock].nextBlock;
      X[S].firstBlock = S_B;
      Q[B].nextBlock = NIL;
      Q[S_B].prevBlock = NIL;

    } else {
      B = Q[X[S].firstBlock].nextBlock;
      S_B = X[S].firstBlock;
      Q[S_B].nextBlock = Q[B].nextBlock;
      if (Q[S_B].nextBlock!=NIL)
        Q[Q[S_B].nextBlock].prevBlock = S_B;
      Q[B].nextBlock = NIL;
      Q[B].prevBlock = NIL;
    }

    //and create a new simple block S1 of X containing B as its only block of Q
    S1 = freeXBlock;
    freeXBlock = X[freeXBlock].nextXBlock;
    Q[B].superBlock = S1;
    X[S1].nextXBlock = NIL;
    //X[S1].prevXBlock = NIL;
    X[S1].firstBlock = B;
    //X[S1].countxS is initialised in step 3

    //check if S is still compound
    if (Q[S_B].nextBlock==NIL){
      //not compound: remove S from C
      C = X[C].nextXBlock;
      if(C!=NIL)
        X[C].prevXBlock = NIL;
      X[S].nextXBlock = NIL;
      //free the space of S as XBlock
      /*WE DO NOT FREE THE BLOCK S: the XBlock still exists but it is
      not in the chain of C*/
    }

  /*Step 3(compute E-1(B))*/
    /*by scanning the edges xEy such that y belongs to B
    and adding each element x in such an edge to E-1(B),
    if it has not already been added.
    Duplicates are suppressed by marking elements: B_1
    Side effect: copy the elements of B in B1
    During the same scan, compute count(x,B)=count(x,S1) because S1={B};
    create a new counter record and make G[x].countxB point to it*/
    y = b1List = Q[B].firstNode;
    b_1List = NIL;
    while (y!=NIL){ //for each y belonging to B
      B1[y] = G[y].nextInBlock; //copy the elements of B in B1
      adj = G[y].adj_1;
      while (adj!=NULL){ //for each node in the adj_1 of y
        x = adj->node;
        if (B_1[x]==numberOfNodes){
          //node not already added to E-1(B)
          B_1[x] = b_1List;
          b_1List = x;
          //create a new counter: it is pointed by G[x].countxB    /*1*/
          cxS = new struct counter;
          cxS->node = x;
          cxS->value = 1;
          G[x].countxB = cxS;               /*1*/
        } else
          (G[x].countxB->value)++;
        adj = adj->next;  //next node in the adj_1 of y
      }
      y = G[y].nextInBlock; //next node y belonging to B
    }

  /*Step 4(refine Q with respect to B)*/
  /*for each block D of Q containing some element of E-1(B)
  split D into D1 = D ^ E-1(B) and D2 = D - D1*/
    dList = NIL;
    //do this by scanning the elements of E-1(B)
    x = b_1List;
    while (x!=NIL){ //for each x belonging to E-1(B)
      //determine the block D of Q containing it
      oldD = G[x].block; //index of D (old block of x)
      //and create an associated block D1 if one does not already exist
      if (splitD[oldD]==numberOfNodes){
        //block D not already split
        splitD[oldD] = dList;
        dList = oldD;
        //create a new block D1
        if (freeQBlock==NIL){ //check for free space in memory
          if(QBlockLimit==MAXINDEX){  
            std::cout << "memory limit";
            std::cin >> x;
            exit(-1);
          }
          freeQBlock = QBlockLimit++;
          Q[freeQBlock].size = 0;
          Q[freeQBlock].nextBlock = NIL;
          splitD[freeQBlock]=numberOfNodes;
          //not necessary to initialise
          //Q[freeQBlock].prevBlock = NIL;
          //Q[freeQBlock].superBlock = NIL;
          //Q[freeQBlock].firstNode = NIL;
        }
        newD = freeQBlock; //index of D1 (new block of x)
        freeQBlock = Q[freeQBlock].nextBlock;
        Q[newD].firstNode = NIL;
        /*insert D1 just after D, so we know that, if D has already been
        split, the associated D1 is the next block*/
        Q[newD].nextBlock = Q[oldD].nextBlock;
        Q[oldD].nextBlock = newD;
        Q[newD].prevBlock = oldD;
        if (Q[newD].nextBlock!=NIL)
          Q[Q[newD].nextBlock].prevBlock = newD;
        Q[newD].superBlock = Q[oldD].superBlock;
      } else
        newD = Q[oldD].nextBlock;
      //move x from D to D1
      if (G[x].prevInBlock!=NIL)
        G[G[x].prevInBlock].nextInBlock = G[x].nextInBlock;
      else
        Q[G[x].block].firstNode = G[x].nextInBlock;
      if (G[x].nextInBlock!=NIL)
        G[G[x].nextInBlock].prevInBlock = G[x].prevInBlock;
      G[x].block = newD;
      G[x].nextInBlock = Q[newD].firstNode;
      G[x].prevInBlock = NIL;
      if (Q[newD].firstNode!=NIL)
        G[Q[newD].firstNode].prevInBlock = x;
      Q[newD].firstNode = x;
      (Q[oldD].size)--;
      (Q[newD].size)++;

      y = x;
      x = B_1[x];
      //re-initialisation of B_1
      B_1[y] = numberOfNodes;
    }//endwhile

    //dList points to the list of new blocks splitD
    d = dList;
    while (d!=NIL){
      if (Q[d].firstNode == NIL){
      //D empty: remove it and free its space
        if(Q[d].prevBlock!=NIL)
          Q[Q[d].prevBlock].nextBlock = Q[d].nextBlock;
        else
          X[Q[d].superBlock].firstBlock = Q[d].nextBlock;
        //we are sure that after D,there is D1
        Q[Q[d].nextBlock].prevBlock = Q[d].prevBlock;
        //re-initialise Q[d]
        //Q[d].size is already zero
        Q[d].prevBlock = NIL;
        Q[d].superBlock = NIL;
        Q[d].firstNode = NIL;
        //free Q[d]
        Q[d].nextBlock = freeQBlock;
        freeQBlock = d;
      }else {
      /*if D nonempty and the superBlock containing D and D1 has been
      made compound by the split, add this block to C*/
        if (Q[d].prevBlock==NIL && Q[Q[d].nextBlock].nextBlock==NIL){
          //D and D1 are the only blocks in this just split Xblock
          X[Q[d].superBlock].nextXBlock = C;
          X[Q[d].superBlock].prevXBlock = NIL;
          C = Q[d].superBlock;
          /*when D became the only block of an XBlock (see the end of step 2)
          we did not free its space and now we can re-use it!!*/
        }
      }

      e = d;
      d = splitD[d];
      //re-initialisation of splitD
      splitD[e] = numberOfNodes;
    }

  /*Step 5(compute E-1(B) - E-1(S_B))*/
    /*Scan each x such that xEy and y belongs to B; determine count(x,B)
    to which G[x].countxB points and count(x,S) to which xEy points
    (y belongs to B -> scan y(E-1)x -> y(E-1)x points to xEy ->
      xEy points to count(x,S))
    To save space we use again the array B_1 to store E-1(B) - E-1(S - B)*/
    y = b1List;
    b_1List = NIL;
    while (y!=NIL){ //for each y belonging to B1
      adj = G[y].adj_1;
      while (adj!=NULL){ //for each node in the adj_1 of y -> scan xEy, y in B
        x = adj->node;
        if(G[x].countxB->value == adj->adj->countxS->value)
          if (B_1[x]==numberOfNodes){
            //x is a node not already added to E-1(S - B)
            B_1[x] = b_1List;
            b_1List = x;
          }
        adj = adj->next;
      }
      y = B1[y];
    }

  /*Step 6(refine Q with respect to S_B)*/
    /*proceed exactly as in Step 4, but scan E-1(B) - E_1(S - B)
    For each block D of Q containing some element of E-1(B) - E-1(S - B)
    split D into D1 = D ^ (E-1(B) - E-1(S - B)) and D2 = D - D1*/
    dList = NIL;
    //do this by scanning the elements of E-1(B) - E-1(S - B)
    x = b_1List;
    while (x!=NIL){
      //to process an element x belonging to E-1(B) - E-1(S - B)
      //determine the block D of Q containing it
      oldD = G[x].block; //index of D (old block of x)
      //and create an associated block D1 if one does not already exist
      if (splitD[oldD]==numberOfNodes){
        //block D not already split
        splitD[oldD] = dList;
        dList = oldD;
        //create a new block D1
        if (freeQBlock==NIL){ //check for free space in memory
          if(QBlockLimit==MAXINDEX){
            std::cout << "memory limit";
            std::cin >> x;
            exit(-1);
          }
          freeQBlock = QBlockLimit++;
          Q[freeQBlock].size = 0;
          Q[freeQBlock].nextBlock = NIL;
          splitD[freeQBlock]=numberOfNodes;
          //not necessary to initialise
          //Q[freeQBlock].prevBlock = NIL;
          //Q[freeQBlock].superBlock = NIL;
          //Q[freeQBlock].firstNode = NIL;
        }
        newD = freeQBlock; //index of D1 (new block of x)
        freeQBlock = Q[freeQBlock].nextBlock;
        Q[newD].firstNode = NIL;
        /*insert D1 just after D, so we know that, if D has already
        been split, the associated D1 is the next block*/
        Q[newD].nextBlock = Q[oldD].nextBlock;
        Q[oldD].nextBlock = newD;
        Q[newD].prevBlock = oldD;
        if (Q[newD].nextBlock!=NIL)
          Q[Q[newD].nextBlock].prevBlock = newD;
        Q[newD].superBlock = Q[oldD].superBlock;
      } else
        newD = Q[oldD].nextBlock;
      //move x from D to D1
      if (G[x].prevInBlock!=NIL)
        G[G[x].prevInBlock].nextInBlock = G[x].nextInBlock;
      else
        Q[G[x].block].firstNode = G[x].nextInBlock;
      if (G[x].nextInBlock!=NIL)
        G[G[x].nextInBlock].prevInBlock = G[x].prevInBlock;
      G[x].block = newD;
      G[x].nextInBlock = Q[newD].firstNode;
      G[x].prevInBlock = NIL;
      if (Q[newD].firstNode!=NIL)
        G[Q[newD].firstNode].prevInBlock = x;
      Q[newD].firstNode = x;
      (Q[oldD].size)--;
      (Q[newD].size)++;

      y = x;
      x = B_1[x];
      //re-initialisation of B_1
      B_1[y] = numberOfNodes;
    }//endwhile

    //dList points to the list of new blocks splitD
    d = dList;
    while (d!=NIL){
      if (Q[d].firstNode == NIL){
        //D empty: remove it and free its space
        if(Q[d].prevBlock!=NIL)
          Q[Q[d].prevBlock].nextBlock = Q[d].nextBlock;
        else
          X[Q[d].superBlock].firstBlock = Q[d].nextBlock;
        Q[Q[d].nextBlock].prevBlock = Q[d].prevBlock;
        //re-initialise Q[d]
        //Q[d].size is already zero
        Q[d].prevBlock = NIL;
        Q[d].superBlock = NIL;
        Q[d].firstNode = NIL;
        //free Q[d]
        Q[d].nextBlock = freeQBlock;
        freeQBlock = d;
      }else {
      /*if D nonempty and the superBlock containing D and D1 has been
      made compound by the split, add this block to C*/
        if (Q[d].prevBlock==NIL && Q[Q[d].nextBlock].nextBlock==NIL){
          //D and D1 are the only blocks in this just split Xblock
          X[Q[d].superBlock].nextXBlock = C;
          X[Q[d].superBlock].prevXBlock = NIL;
          C = Q[d].superBlock;
          /*when D became the only block of an XBlock (see the end of step 2)
          we did not free its space and now we can re-use it!!*/
        }
      }
      e = d;
      d = splitD[d];
      //re-initialisation of splitD
      splitD[e] = numberOfNodes;
    }

  /*Step 7(update counts)*/
    /*scan the edges xEy tc y belongs to B1.
    To process an edge decrement count(x,S) (to which xEy points).
    If this count becomes zero delete the count record,
    and make xEy point to count(x,B) (to which x points).
    Discard B1 (re-initialise it).*/
    y = b1List;
    while (y!=NIL){ //for each y belonging to B
      adj = G[y].adj_1;
      while (adj!=NULL){//for each node in the adj_1 of y -> scan xEy, y in B
        x = adj->node;
        cxS = adj->adj->countxS;
        if (cxS->value!=1){
          (cxS->value)--;
          adj->adj->countxS = G[x].countxB;
        }
        else{ //count(x,S) becomes zero
          //make xEy point to count(x,B)
          adj->adj->countxS = G[x].countxB;
          //delete count(x,S)
          delete cxS;
        }
        adj = adj->next;
      }
      x = y;
      y = B1[y];
      //re-initialisation of B1
      B1[x] = numberOfNodes;
    }
  }//end while
}

