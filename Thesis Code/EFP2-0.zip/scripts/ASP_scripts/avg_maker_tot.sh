. scripts/ASP_scripts/avg_maker.sh;
sleep 5s;
. scripts/ASP_scripts/avg_maker_splitted.sh;
