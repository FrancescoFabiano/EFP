#copy and paste this to test (or simply execute)
bin/efp.out exp/ICAPS20/Coin_In_The_Box/Coin_in_the_Box__pl_5.txt -debug -bis PT -e open_a
#bin/efp.out exp/ICAPS20/Coin_In_The_Box/Coin_in_the_Box__pl_5.txt -debug -bisimulation -e open_a, peek_a, signal_a_b, signal_a_c, shout_tail_a 
