# PLATO
An ASP based comprehensive Multi-Agent Epistemic Planner
