####################################
# This file houses the various
#  GTK views that will contain
#  the user defined widgets.
#############################
